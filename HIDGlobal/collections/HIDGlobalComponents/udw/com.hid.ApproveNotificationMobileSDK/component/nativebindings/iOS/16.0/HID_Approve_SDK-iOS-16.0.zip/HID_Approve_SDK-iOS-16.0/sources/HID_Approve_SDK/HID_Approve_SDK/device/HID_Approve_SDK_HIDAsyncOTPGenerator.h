#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_HID_Approve_SDK_HIDAsyncOTPGenerator_symbols(JSContext*);
@protocol HIDOTPInputAlgorithmParametersInstanceExports<JSExport>
@end
@protocol HIDOTPInputAlgorithmParametersClassExports<JSExport>
@end
@protocol HIDAsyncOTPGeneratorInstanceExports_<JSExport, HIDOTPGeneratorInstanceExports_>
JSExportAs(computeResponseWithChallengeWithInputParamsError,
-(NSString *) jscomputeResponse: (NSString *) password withChallenge: (NSString *) challenge withInputParams: (HIDOTPInputAlgorithmParameters *) input error: (JSValue *) error );
JSExportAs(computeServerResponseWithClientChallengeWithServerChallengeWithInputParamsError,
-(NSString *) jscomputeServerResponse: (NSString *) password withClientChallenge: (NSString *) clientChallenge withServerChallenge: (NSString *) serverChallenge withInputParams: (HIDOTPInputAlgorithmParameters *) input error: (JSValue *) error );
JSExportAs(getChallenge,
-(NSString *) jsgetChallenge: (JSValue *) error );
JSExportAs(computeClientResponseWithClientChallengeWithServerChallengeWithInputParamsError,
-(NSString *) jscomputeClientResponse: (NSString *) password withClientChallenge: (NSString *) clientChallenge withServerChallenge: (NSString *) serverChallenge withInputParams: (HIDOTPInputAlgorithmParameters *) input error: (JSValue *) error );
JSExportAs(computeSignatureWithSigChallengeWithClientChallengeWithInputParamsError,
-(NSString *) jscomputeSignature: (NSString *) password withSigChallenge: (NSString *) sigChallenge withClientChallenge: (NSString *) clientChallenge withInputParams: (HIDOTPInputAlgorithmParameters *) input error: (JSValue *) error );
JSExportAs(formatSignatureChallengeError,
-(NSString *) jsformatSignatureChallenge: (NSArray *) inputData error: (JSValue *) error );
-(NSString *) getType;
@end
@protocol HIDAsyncOTPGeneratorClassExports_<JSExport, HIDOTPGeneratorClassExports_>
@end
#pragma clang diagnostic pop
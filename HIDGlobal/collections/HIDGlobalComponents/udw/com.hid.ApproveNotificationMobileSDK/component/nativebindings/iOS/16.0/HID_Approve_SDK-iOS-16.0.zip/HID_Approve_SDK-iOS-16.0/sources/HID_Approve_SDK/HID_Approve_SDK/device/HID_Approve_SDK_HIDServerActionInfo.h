#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_HID_Approve_SDK_HIDServerActionInfo_symbols(JSContext*);
@protocol HIDServerActionInfoInstanceExports_<JSExport>
-(NSString *) getUniqueIdentifier;
JSExportAs(getContainer,
-(id) jsgetContainer: (JSValue *) error );
JSExportAs(getProtectionKey,
-(id) jsgetProtectionKey: (JSValue *) error );
JSExportAs(getActionWithParamsError,
-(id) jsgetAction: (NSString *) sessionPassword withParams: (NSArray *) parameters error: (JSValue *) error );
@end
@protocol HIDServerActionInfoClassExports_<JSExport>
@end
#pragma clang diagnostic pop
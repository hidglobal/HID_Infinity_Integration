/* ---------------------------------------------------------------------------
 (c) 2015-2024, HID Global Corporation, part of ASSA ABLOY.
 All rights reserved.
          
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 - Redistributions of source code must retain the above copyright notice,
 this list of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice,
 this list of conditions and the following disclaimer in the documentation
 and/or other materials provided with the distribution.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
--------------------------------------------------------------------------- */

#import <Foundation/Foundation.h>
#import "HIDContainer.h"
#import "HIDTransaction.h"
#import "HIDKey.h"

/**
 * \file HIDTransactionInfo.h
 * \brief Transaction details.
 *
 */

/**
 * \brief Transaction details.
 * \deprecated Deprecated in SDK 5.7.1. was replaced by HIDServerActionInfo
 */
__attribute__((deprecated))
@protocol HIDTransactionInfo
/**
 * \brief deprecated Retrieves the container associated with that transaction.
 * \param error error details. It may be nil.
 * <p>
 * Possible error codes are:
 * <ul>
 * <li>#HIDInternal if unexpected error occurred.</li>
 * </ul>
 * </p>
 * \return the container, nil if an error occurs.
 * \deprecated Deprecated in SDK 5.7.1.
 */
- (id<HIDContainer>)getContainer:(NSError**)error __attribute__((deprecated));
/**
 * \brief Retrieves the transaction protection key associated with that transaction.
 * \param error error details. It may be nil.
 * <p>
 * Possible error codes are:
 * <ul>
 * <li>#HIDInternal if unexpected error occurred.</li>
 * </ul>
 * </p>
 * \return The transaction protection session key, nil if an error occurs.
 * \deprecated Deprecated in SDK 5.7.1.
 */
- (id<HIDKey>)getTransactionProtectionKey:(NSError**)error __attribute__((deprecated));
/**
 * \brief Retrieves the transaction unique identifier.
 * \return transaction challenge id
 * \deprecated Deprecated in SDK 5.7.1.
 */
- (uint64_t)getUniqueIdentifier __attribute__((deprecated));

/**
 * \brief Retrieves a transaction associated with this transaction info.
 * \param sessionPassword transaction protection key password (can be nil if not required by the policy) 
 * \param parameters NSArray of HIDParameter objects required to retrieve the transaction (such as password if needed).
 * \param error error details. It may be nil.
 * <p>
 * Possible error codes are:
 * <ul>
 * <li>#HIDAuthentication if password is incorrect.</li>
 * <li>#HIDTransactionExpired if transaction is no longer valid</li>
 * <li>#HIDCredentialsExpired if key is no longer valid</li>
 * <li>#HIDInternal if unexpected error occurred.</li>
 * <li>#HIDPasswordExpired if expired password is given (changePassword required).
 * <li>#HIDServerAuthentication if server rejects authentication</li>
 * <li>#HIDInvalidArgument if the given parameters are invalid or required parameters are missing.</li>
 * </ul>
 * </p>
 * \return a HIDTransaction instance containing transaction details, nil if an error occurs.
 * \deprecated Deprecated in SDK 5.7.1.
 */
- (id<HIDTransaction>)getTransaction:(NSString*)sessionPassword withParams:(NSArray*)parameters error:(NSError**)error __attribute__((deprecated));

@end

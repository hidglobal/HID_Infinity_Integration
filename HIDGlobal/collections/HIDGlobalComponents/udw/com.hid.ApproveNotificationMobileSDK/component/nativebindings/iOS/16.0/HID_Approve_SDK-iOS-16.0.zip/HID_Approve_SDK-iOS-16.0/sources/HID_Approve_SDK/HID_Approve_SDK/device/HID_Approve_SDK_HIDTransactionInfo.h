#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_HID_Approve_SDK_HIDTransactionInfo_symbols(JSContext*);
@protocol HIDTransactionInfoInstanceExports_<JSExport>
JSExportAs(getTransactionProtectionKey,
-(id) jsgetTransactionProtectionKey: (JSValue *) error );
-(uint64_t) getUniqueIdentifier;
JSExportAs(getContainer,
-(id) jsgetContainer: (JSValue *) error );
JSExportAs(getTransactionWithParamsError,
-(id) jsgetTransaction: (NSString *) sessionPassword withParams: (NSArray *) parameters error: (JSValue *) error );
@end
@protocol HIDTransactionInfoClassExports_<JSExport>
@end
#pragma clang diagnostic pop
#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_HID_Approve_SDK_HIDContainerInitialization_symbols(JSContext*);
@protocol HIDContainerInitializationInstanceExports<JSExport>
@property () NSString * activationCode;
@property () NSString * inviteCode;
@property () NSString * userId;
@property () NSString * serverURL;
@end
@protocol HIDContainerInitializationClassExports<JSExport>
@end
@protocol HIDContainerConfigurationInstanceExports<JSExport>
@property () NSString * deviceFriendlyName;
@property () NSString * containerFriendlyName;
@property () NSString * pushId;
@end
@protocol HIDContainerConfigurationClassExports<JSExport>
@end
@protocol HIDContainerRenewalInstanceExports<JSExport>
@property () NSString * password;
@end
@protocol HIDContainerRenewalClassExports<JSExport>
@end
#pragma clang diagnostic pop
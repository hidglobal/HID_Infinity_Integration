#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_HID_Approve_SDK_HIDProgressListener_symbols(JSContext*);
@protocol HIDPasswordPromptEventInstanceExports<JSExport, HIDEventInstanceExports_>
@property (readonly) Boolean passwordInitialization;
@property (readonly) NSDate * expiryDate;
@property (readonly) id passwordPolicy;
@end
@protocol HIDPasswordPromptEventClassExports<JSExport, HIDEventClassExports_>
@end
@protocol HIDPasswordPromptResultInstanceExports<JSExport>
@property (strong) NSString * password;
@end
@protocol HIDPasswordPromptResultClassExports<JSExport>
@end
@protocol HIDProgressEventInstanceExports<JSExport, HIDEventInstanceExports_>
@end
@protocol HIDProgressEventClassExports<JSExport, HIDEventClassExports_>
@end
@protocol HIDEventResultInstanceExports<JSExport>
@end
@protocol HIDEventResultClassExports<JSExport>
@end
@protocol HIDEventInstanceExports_<JSExport>
@property (readonly) NSString * ID;
@property (readonly) NSArray * parameters;
@end
@protocol HIDEventClassExports_<JSExport>
@end
@protocol HIDProgressListenerInstanceExports_<JSExport>
-(HIDEventResult *) onEventReceived: (id) event ;
@end
@protocol HIDProgressListenerClassExports_<JSExport>
@end
#pragma clang diagnostic pop
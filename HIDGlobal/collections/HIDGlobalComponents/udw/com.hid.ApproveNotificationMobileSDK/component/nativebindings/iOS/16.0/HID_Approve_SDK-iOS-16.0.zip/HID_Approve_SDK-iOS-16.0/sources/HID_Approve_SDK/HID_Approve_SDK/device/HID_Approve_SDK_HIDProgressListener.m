#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
	class_addProtocol([HIDPasswordPromptEvent class], @protocol(HIDPasswordPromptEventInstanceExports));
	class_addProtocol([HIDPasswordPromptEvent class], @protocol(HIDPasswordPromptEventClassExports));
	class_addProtocol([HIDPasswordPromptResult class], @protocol(HIDPasswordPromptResultInstanceExports));
	class_addProtocol([HIDPasswordPromptResult class], @protocol(HIDPasswordPromptResultClassExports));
	class_addProtocol([HIDProgressEvent class], @protocol(HIDProgressEventInstanceExports));
	class_addProtocol([HIDProgressEvent class], @protocol(HIDProgressEventClassExports));
	class_addProtocol([HIDEventResult class], @protocol(HIDEventResultInstanceExports));
	class_addProtocol([HIDEventResult class], @protocol(HIDEventResultClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
	context[@"Continue"] = @0;
	context[@"Cancel"] = @1;
	context[@"Abort"] = @2;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void HID_Approve_SDK_HIDProgressListenerProtocols()
{
	(void)@protocol(HIDEvent);
	(void)@protocol(HIDProgressListener);
}
void load_HID_Approve_SDK_HIDProgressListener_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop

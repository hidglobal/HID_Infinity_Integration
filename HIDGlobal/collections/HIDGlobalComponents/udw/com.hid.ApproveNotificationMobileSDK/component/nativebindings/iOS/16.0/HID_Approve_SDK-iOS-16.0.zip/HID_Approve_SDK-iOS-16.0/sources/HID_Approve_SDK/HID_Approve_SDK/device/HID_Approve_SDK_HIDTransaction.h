#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_HID_Approve_SDK_HIDTransaction_symbols(JSContext*);
@protocol HIDTransactionInstanceExports_<JSExport, HIDServerActionInstanceExports_>
-(NSArray *) getAllowedStatuses;
JSExportAs(getSigningKey,
-(id) jsgetSigningKey: (JSValue *) error );
-(NSString *) toString;
JSExportAs(getAction,
-(NSString *) jsgetAction: (JSValue *) error );
JSExportAs(setStatusWithSigningPasswordWithSessionPasswordWithParamsError,
-(BOOL) jssetStatus: (NSString *) status withSigningPassword: (NSString *) signPassword withSessionPassword: (NSString *) sessionPassword withParams: (NSArray *) parameters error: (JSValue *) error );
JSExportAs(getDate,
-(NSDate *) jsgetDate: (JSValue *) error );
JSExportAs(getExpiryDate,
-(NSDate *) jsgetExpiryDate: (JSValue *) error );
@end
@protocol HIDTransactionClassExports_<JSExport, HIDServerActionClassExports_>
@end
#pragma clang diagnostic pop
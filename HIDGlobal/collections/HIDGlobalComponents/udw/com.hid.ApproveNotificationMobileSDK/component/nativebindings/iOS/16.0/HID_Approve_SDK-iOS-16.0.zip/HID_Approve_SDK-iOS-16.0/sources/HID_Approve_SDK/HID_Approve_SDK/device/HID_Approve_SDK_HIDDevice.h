#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_HID_Approve_SDK_HIDDevice_symbols(JSContext*);
@protocol HIDDeviceFactoryInstanceExports<JSExport>
JSExportAs(newInstanceError,
-(id) jsnewInstance: (HIDConnectionConfiguration *) config error: (JSValue *) error );
JSExportAs(newInstanceWithSessionPasswordError,
-(id) jsnewInstance: (HIDConnectionConfiguration *) config withSessionPassword: (NSString *) sessionPassword error: (JSValue *) error );
@end
@protocol HIDDeviceFactoryClassExports<JSExport>
JSExportAs(reset,
+(BOOL) jsreset: (JSValue *) error );
+(id) factory;
@end
@protocol HIDDeviceInstanceExports_<JSExport>
JSExportAs(retrieveActionInfoWithUserIDError,
-(id) jsretrieveActionInfo: (NSString *) actionId withUserID: (NSString *) userId error: (JSValue *) error );
JSExportAs(getVersion,
-(NSString *) jsgetVersion: (JSValue *) error );
JSExportAs(retrieveTransactionInfoError,
-(id) jsretrieveTransactionInfo: (NSString *) transactionId error: (JSValue *) error );
JSExportAs(updateDeviceInfoWithValueWithPasswordWithParamsError,
-(BOOL) jsupdateDeviceInfo: (NSString *) propertyId withValue: (NSString *) propertyValue withPassword: (NSString *) sessionPassword withParams: (NSArray *) parameters error: (JSValue *) error );
JSExportAs(deleteContainerWithSessionPasswordWithParamsError,
-(BOOL) jsdeleteContainer: (NSInteger) containerId withSessionPassword: (NSString *) sessionPassword withParams: (NSArray *) parameters error: (JSValue *) error );
JSExportAs(getDeviceInfoError,
-(NSString *) jsgetDeviceInfo: (NSString *) propertyId error: (JSValue *) error );
JSExportAs(setConnectionConfigurationError,
-(BOOL) jssetConnectionConfiguration: (HIDConnectionConfiguration *) config error: (JSValue *) error );
JSExportAs(retrieveActionInfoError,
-(id) jsretrieveActionInfo: (NSString *) actionId error: (JSValue *) error );
JSExportAs(findContainersError,
-(NSArray *) jsfindContainers: (NSArray *) filter error: (JSValue *) error );
JSExportAs(createContainerWithSessionPasswordWithListenerError,
-(id) jscreateContainer: (HIDContainerInitialization *) config withSessionPassword: (NSString *) sessionPassword withListener: (NSObject *) listener error: (JSValue *) error );
@end
@protocol HIDDeviceClassExports_<JSExport>
@end
#pragma clang diagnostic pop
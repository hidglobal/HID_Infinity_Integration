#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_HID_Approve_SDK_HIDHOTPGenerator_symbols(JSContext*);
@protocol HIDHOTPAlgorithmParametersInstanceExports_<JSExport, HIDAlgorithmParametersInstanceExports_>
-(uint64_t) getCounter;
-(BOOL) isCheckSum;
-(int) getCodeDigits;
-(NSString *) getMACAlgo;
-(int) getTruncationOffset;
@end
@protocol HIDHOTPAlgorithmParametersClassExports_<JSExport, HIDAlgorithmParametersClassExports_>
@end
#pragma clang diagnostic pop
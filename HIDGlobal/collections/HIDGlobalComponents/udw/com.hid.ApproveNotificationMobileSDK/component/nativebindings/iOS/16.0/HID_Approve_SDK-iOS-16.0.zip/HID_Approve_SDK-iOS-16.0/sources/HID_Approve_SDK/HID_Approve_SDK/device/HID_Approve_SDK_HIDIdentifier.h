#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_HID_Approve_SDK_HIDIdentifier_symbols(JSContext*);
@protocol HIDIdentifierInstanceExports<JSExport>
@property (retain,nonatomic) NSString * type;
@property (retain,nonatomic) NSString * ID;
JSExportAs(initWithIdWithType,
-(id) jsinitWithId: (NSString *) identifier withType: (NSString *) type );
@end
@protocol HIDIdentifierClassExports<JSExport>
+(id) identifier: (NSString *) identifier withType: (NSString *) type ;
@end
#pragma clang diagnostic pop
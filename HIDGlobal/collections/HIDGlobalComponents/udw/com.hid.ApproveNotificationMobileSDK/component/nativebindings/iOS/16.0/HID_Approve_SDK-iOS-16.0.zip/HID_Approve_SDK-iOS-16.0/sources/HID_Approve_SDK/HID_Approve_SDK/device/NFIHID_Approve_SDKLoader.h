#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIHID_Approve_SDKModules(JSContext* context);
JSValue* extractNFIHID_Approve_SDKStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIHID_Approve_SDKStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);

#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_HID_Approve_SDK_HIDContainer_symbols(JSContext*);
@protocol HIDContainerInstanceExports_<JSExport>
JSExportAs(getCreationDate,
-(NSDate *) jsgetCreationDate: (JSValue *) error );
-(NSString *) getServerURL;
JSExportAs(setNameError,
-(BOOL) jssetName: (NSString *) name error: (JSValue *) error );
JSExportAs(setPropertyWithValueError,
-(BOOL) jssetProperty: (NSString *) propertyId withValue: (NSString *) propertyValue error: (JSValue *) error );
JSExportAs(getOriginalCreationDate,
-(NSDate *) jsgetOriginalCreationDate: (JSValue *) error );
-(NSString *) getName;
JSExportAs(renewWithSessionPasswordWithListenerError,
-(Boolean) jsrenew: (HIDContainerRenewal *) config withSessionPassword: (NSString *) sessionPassword withListener: (NSObject *) listener error: (JSValue *) error );
JSExportAs(addKeyWithProtectionPolicyIdWithPasswordError,
-(BOOL) jsaddKey: (HIDKeySpec *) keySpec withProtectionPolicyId: (HIDIdentifier *) protectionPolicyId withPassword: (NSString *) password error: (JSValue *) error );
JSExportAs(setConnectionConfigurationError,
-(BOOL) jssetConnectionConfiguration: (HIDConnectionConfiguration *) config error: (JSValue *) error );
-(NSInteger) getId;
-(NSString *) getUserId;
-(BOOL) isFIPSModeEnabled;
JSExportAs(retrieveTransactionIdsWithParamsError,
-(NSArray *) jsretrieveTransactionIds: (NSString *) sessionPassword withParams: (NSArray *) parameters error: (JSValue *) error );
JSExportAs(findKeysError,
-(NSArray *) jsfindKeys: (NSArray *) filter error: (JSValue *) error );
JSExportAs(getProtectionPolicy,
-(id) jsgetProtectionPolicy: (JSValue *) error );
JSExportAs(getPropertyError,
-(NSString *) jsgetProperty: (NSString *) propertyId error: (JSValue *) error );
JSExportAs(updateDeviceInfoWithValueWithPasswordWithParamsError,
-(BOOL) jsupdateDeviceInfo: (NSString *) propertyId withValue: (NSString *) propertyValue withPassword: (NSString *) sessionPassword withParams: (NSArray *) parameters error: (JSValue *) error );
JSExportAs(getRenewalDate,
-(NSDate *) jsgetRenewalDate: (JSValue *) error );
JSExportAs(isRenewableError,
-(Boolean) jsisRenewable: (NSString *) sessionPassword error: (JSValue *) error );
JSExportAs(getExpiryDate,
-(NSDate *) jsgetExpiryDate: (JSValue *) error );
@end
@protocol HIDContainerClassExports_<JSExport>
@end
#pragma clang diagnostic pop
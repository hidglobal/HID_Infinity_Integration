#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation HIDParameter (Exports)
-(id) jsinitWithString: (NSString *) value forKey: (NSString *) key 
{
	id resultVal__;
	resultVal__ = [[self initWithString: value forKey: key ] autorelease];
	return resultVal__;
}
@end
static void addProtocols()
{
	class_addProtocol([HIDParameter class], @protocol(HIDParameterInstanceExports));
	class_addProtocol([HIDParameter class], @protocol(HIDParameterClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
	context[@"HIDParameterEncodingNone"] = @0;
	context[@"HIDParameterEncodingBase64"] = @1;
	context[@"HIDParameterEncodingByteArray"] = @2;
	context[@"HIDParameterEncodingHex"] = @3;
	context[@"HIDParameterEncodingDecimal"] = @4;
	context[@"HIDParameterEncodingUTF8"] = @5;
	context[@"HIDParameterEncodingDefault"] = @0;

	context[@"HIDParameterTypeString"] = @0;
	context[@"HIDParameterTypeInteger"] = @1;
	context[@"HIDParameterTypeByteArray"] = @2;
	context[@"HIDParameterTypeLong"] = @3;
	context[@"HIDParameterTypeDefault"] = @0;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void load_HID_Approve_SDK_HIDParameter_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop

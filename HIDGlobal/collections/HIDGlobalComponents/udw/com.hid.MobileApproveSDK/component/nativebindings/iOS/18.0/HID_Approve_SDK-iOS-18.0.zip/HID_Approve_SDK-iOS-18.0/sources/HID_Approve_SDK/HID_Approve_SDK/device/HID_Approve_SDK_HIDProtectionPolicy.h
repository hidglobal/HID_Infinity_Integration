#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_HID_Approve_SDK_HIDProtectionPolicy_symbols(JSContext*);
@protocol HIDDelayLockPolicyInstanceExports_<JSExport, HIDLockPolicyInstanceExports_>
-(int) delay;
-(int) counter;
@end
@protocol HIDDelayLockPolicyClassExports_<JSExport, HIDLockPolicyClassExports_>
@end
@protocol HIDBioPasswordPolicyInstanceExports_<JSExport, HIDPasswordPolicyInstanceExports_>
-(HIDBioAuthenticationState) getBioAuthenticationState;
JSExportAs(enableBioAuthenticationError,
-(BOOL) jsenableBioAuthentication: (NSString *) sPassword error: (JSValue *) error );
@end
@protocol HIDBioPasswordPolicyClassExports_<JSExport, HIDPasswordPolicyClassExports_>
@end
@protocol HIDPasswordPolicyInstanceExports_<JSExport, HIDProtectionPolicyInstanceExports_>
-(int) maxNumeric;
-(int) minAge;
-(int) getCacheTimeout;
JSExportAs(verifyPasswordError,
-(BOOL) jsverifyPassword: (NSString *) password error: (JSValue *) error );
-(int) minUpperCase;
-(int) minLength;
-(int) maxAlpha;
-(BOOL) isCacheEnabled;
-(int) maxAge;
-(int) currentAge;
-(int) minNumeric;
-(int) minNonAlpha;
-(int) maxHistory;
JSExportAs(changePasswordNewError,
-(BOOL) jschangePassword: (NSString *) oldPassword new: (NSString *) newPassword error: (JSValue *) error );
-(int) minLowerCase;
-(int) maxUpperCase;
-(int) maxLength;
-(int) minAlpha;
-(int) maxLowerCase;
-(BOOL) isSequenceAllowed;
-(int) maxNonAlpha;
@end
@protocol HIDPasswordPolicyClassExports_<JSExport, HIDProtectionPolicyClassExports_>
@end
@protocol HIDDevicePolicyInstanceExports_<JSExport, HIDProtectionPolicyInstanceExports_>
@end
@protocol HIDDevicePolicyClassExports_<JSExport, HIDProtectionPolicyClassExports_>
@end
@protocol HIDProtectionPolicyInstanceExports_<JSExport, NSObjectInstanceExports_>
-(id) lockPolicy;
-(HIDPolicyType) policyType;
-(HIDIdentifier *) policyId;
@end
@protocol HIDProtectionPolicyClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol HIDCounterLockPolicyInstanceExports_<JSExport, HIDLockPolicyInstanceExports_>
-(int) counter;
@end
@protocol HIDCounterLockPolicyClassExports_<JSExport, HIDLockPolicyClassExports_>
@end
@protocol HIDLockPolicyInstanceExports_<JSExport>
-(HIDLockType) lockType;
@end
@protocol HIDLockPolicyClassExports_<JSExport>
@end
#pragma clang diagnostic pop
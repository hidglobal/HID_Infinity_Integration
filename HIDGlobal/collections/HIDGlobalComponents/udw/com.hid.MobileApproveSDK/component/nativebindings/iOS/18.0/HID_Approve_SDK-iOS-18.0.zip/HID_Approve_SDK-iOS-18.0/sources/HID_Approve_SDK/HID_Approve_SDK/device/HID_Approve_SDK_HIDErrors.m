#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
	context[@"HIDInternal"] = @0;
	context[@"HIDNotImplemented"] = @1;
	context[@"HIDUnsupportedOperation"] = @2;
	context[@"HIDInvalidArgument"] = @3;
	context[@"HIDKeyGenerationFailure"] = @4;
	context[@"HIDProtectionPolicyFailure"] = @5;
	context[@"HIDSecureDataFailure"] = @6;
	context[@"HIDUnsupportedVersion"] = @7;
	context[@"HIDInvalidContainer"] = @8;
	context[@"HIDInexplicitContainer"] = @9;
	context[@"HIDAuthentication"] = @100;
	context[@"HIDInvalidPassword"] = @101;
	context[@"HIDCredentialsExpired"] = @102;
	context[@"HIDPasswordExpired"] = @103;
	context[@"HIDPasswordNotYetUpdatable"] = @104;
	context[@"HIDPasswordRequired"] = @105;
	context[@"HIDLostCredentials"] = @106;
	context[@"HIDInvalidChallengeTooLong"] = @107;
	context[@"HIDInvalidChallengeBadFormat"] = @108;
	context[@"HIDPasswordCancelled"] = @109;
	context[@"HIDUnsupportedDevice"] = @200;
	context[@"HIDUnsafeDevice"] = @201;
	context[@"HIDFingerprintNotEnrolled"] = @202;
	context[@"HIDUserCancelled"] = @203;
	context[@"HIDFingerprintAuthenticationRequired"] = @204;
	context[@"HIDUnsupportedOperationMode"] = @205;
	context[@"HIDServerAuthentication"] = @300;
	context[@"HIDServerVersion"] = @301;
	context[@"HIDServerProtocol"] = @302;
	context[@"HIDRemote"] = @303;
	context[@"HIDServerUnsupportedOperation"] = @304;
	context[@"HIDServerOperationFailed"] = @305;
	context[@"HIDTransactionExpired"] = @1000;
	context[@"HIDTransactionContainerInvalid"] = @1001;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &HIDErrorDomain;
	if (p != NULL) context[@"HIDErrorDomain"] = HIDErrorDomain;
}
void load_HID_Approve_SDK_HIDErrors_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop

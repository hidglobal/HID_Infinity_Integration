#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_HID_Approve_SDK_HIDKey_symbols(JSContext*);
@protocol HIDKeyInstanceExports_<JSExport>
JSExportAs(getEncodedError,
-(NSData *) jsgetEncoded: (NSString *) password error: (JSValue *) error );
JSExportAs(getDefaultOTPGenerator,
-(id) jsgetDefaultOTPGenerator: (JSValue *) error );
JSExportAs(getFormat,
-(NSString *) jsgetFormat: (JSValue *) error );
-(HIDIdentifier *) getId;
JSExportAs(getProtectionPolicy,
-(id) jsgetProtectionPolicy: (JSValue *) error );
JSExportAs(getPropertyError,
-(NSString *) jsgetProperty: (NSString *) propertyId error: (JSValue *) error );
JSExportAs(getEncoded,
-(NSData *) jsgetEncoded: (JSValue *) error );
JSExportAs(isExtractable,
-(BOOL) jsisExtractable: (JSValue *) error );
JSExportAs(getAlgorithm,
-(NSString *) jsgetAlgorithm: (JSValue *) error );
@end
@protocol HIDKeyClassExports_<JSExport>
@end
#pragma clang diagnostic pop
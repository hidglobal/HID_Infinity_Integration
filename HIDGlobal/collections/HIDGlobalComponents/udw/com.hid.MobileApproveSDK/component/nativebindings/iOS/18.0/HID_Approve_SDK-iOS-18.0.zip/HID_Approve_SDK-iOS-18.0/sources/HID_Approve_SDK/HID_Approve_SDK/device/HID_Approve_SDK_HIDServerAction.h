#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_HID_Approve_SDK_HIDServerAction_symbols(JSContext*);
@protocol HIDServerActionInstanceExports_<JSExport>
JSExportAs(getDate,
-(NSDate *) jsgetDate: (JSValue *) error );
JSExportAs(getPayload,
-(NSString *) jsgetPayload: (JSValue *) error );
-(NSString *) toString;
JSExportAs(getAction,
-(NSString *) jsgetAction: (JSValue *) error );
JSExportAs(getExpiryDate,
-(NSDate *) jsgetExpiryDate: (JSValue *) error );
@end
@protocol HIDServerActionClassExports_<JSExport>
@end
#pragma clang diagnostic pop
#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
	class_addProtocol([HIDContainerInitialization class], @protocol(HIDContainerInitializationInstanceExports));
	class_addProtocol([HIDContainerInitialization class], @protocol(HIDContainerInitializationClassExports));
	class_addProtocol([HIDContainerConfiguration class], @protocol(HIDContainerConfigurationInstanceExports));
	class_addProtocol([HIDContainerConfiguration class], @protocol(HIDContainerConfigurationClassExports));
	class_addProtocol([HIDContainerRenewal class], @protocol(HIDContainerRenewalInstanceExports));
	class_addProtocol([HIDContainerRenewal class], @protocol(HIDContainerRenewalClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void load_HID_Approve_SDK_HIDContainerInitialization_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop

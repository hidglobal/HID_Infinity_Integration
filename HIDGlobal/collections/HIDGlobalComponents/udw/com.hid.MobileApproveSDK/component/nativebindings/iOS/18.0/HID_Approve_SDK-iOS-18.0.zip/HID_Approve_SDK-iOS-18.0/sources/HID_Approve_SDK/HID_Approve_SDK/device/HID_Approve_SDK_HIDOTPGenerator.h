#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_HID_Approve_SDK_HIDOTPGenerator_symbols(JSContext*);
@protocol HIDAlgorithmParametersInstanceExports_<JSExport>
-(NSString *) getStandardVersion;
-(NSArray *) getModes;
@end
@protocol HIDAlgorithmParametersClassExports_<JSExport>
@end
@protocol HIDOTPGeneratorInstanceExports_<JSExport, NSObjectInstanceExports_>
-(id) getAlgorithmParameters;
-(NSString *) getName;
-(NSString *) getType;
-(NSString *) getVersion;
@end
@protocol HIDOTPGeneratorClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop
#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_HID_Approve_SDK_HIDSyncOTPGenerator_symbols(JSContext*);
@protocol HIDSyncOTPGeneratorInstanceExports_<JSExport, HIDOTPGeneratorInstanceExports_>
JSExportAs(getOTPError,
-(NSString *) jsgetOTP: (NSString *) password error: (JSValue *) error );
@end
@protocol HIDSyncOTPGeneratorClassExports_<JSExport, HIDOTPGeneratorClassExports_>
@end
#pragma clang diagnostic pop
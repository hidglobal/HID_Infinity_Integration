#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_HID_Approve_SDK_HIDKeySpec_symbols(JSContext*);
@protocol HIDKeySpecInstanceExports<JSExport>
-(void) setUsage: (NSString *) keyUsage ;
-(void) setLabel: (NSString *) label ;
-(NSString *) getAlgorithm;
-(NSString *) getLabel;
-(NSString *) getUsage;
JSExportAs(initWithFormat,
-(id) jsinit: (NSData *) key withFormat: (NSString *) format );
-(void) setAlgorithm: (NSString *) algorithm ;
-(NSData *) getKey;
-(NSString *) getFormat;
@end
@protocol HIDKeySpecClassExports<JSExport>
@end
#pragma clang diagnostic pop
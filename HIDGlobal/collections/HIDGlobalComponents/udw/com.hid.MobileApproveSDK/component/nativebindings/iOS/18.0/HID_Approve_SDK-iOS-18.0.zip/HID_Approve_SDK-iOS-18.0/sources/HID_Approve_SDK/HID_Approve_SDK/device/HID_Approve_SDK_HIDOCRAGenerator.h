#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_HID_Approve_SDK_HIDOCRAGenerator_symbols(JSContext*);
@protocol HIDOCRAInputAlgorithmParametersInstanceExports<JSExport>
-(NSString *) getSession;
-(void) setPin: (NSString *) pin ;
JSExportAs(initSessionInfo,
-(id) jsinit: (NSString *) pin sessionInfo: (NSString *) session );
-(void) setSession: (NSString *) sessionInfo ;
-(NSString *) getPin;
@end
@protocol HIDOCRAInputAlgorithmParametersClassExports<JSExport>
@end
@protocol HIDOCRASuiteInstanceExports_<JSExport>
-(NSString *) getPINHashAlgo;
-(int) getCodeDigits;
-(int) getSessionLength;
-(BOOL) isPinRequired;
-(BOOL) hasTime;
-(BOOL) isSessionRequired;
-(int) getMaxChallengeLength;
-(BOOL) hasCounter;
-(uint64_t) getTimeStep;
-(NSString *) toString;
-(NSString *) getCryptoFunction;
-(NSString *) getChallengeFormat;
-(int) getMinChallengeLength;
@end
@protocol HIDOCRASuiteClassExports_<JSExport>
@end
@protocol HIDOCRAGeneratorInstanceExports_<JSExport, HIDAsyncOTPGeneratorInstanceExports_>
@end
@protocol HIDOCRAGeneratorClassExports_<JSExport, HIDAsyncOTPGeneratorClassExports_>
@end
@protocol HIDOCRAAlgorithmParametersInstanceExports_<JSExport, HIDAlgorithmParametersInstanceExports_>
-(id) getClientOCRASuite;
-(id) getServerOCRASuite;
@end
@protocol HIDOCRAAlgorithmParametersClassExports_<JSExport, HIDAlgorithmParametersClassExports_>
@end
#pragma clang diagnostic pop
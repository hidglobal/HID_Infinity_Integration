#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreImage_CIRAWFilter_symbols(JSContext*);
@protocol CIRAWFilterInstanceExports<JSExport>
@property (readonly) NSArray * supportedDecoderVersions;
@property (readonly) CGSize nativeSize;
@property (readonly) NSDictionary * properties;
@property (readwrite) CGImagePropertyOrientation orientation;
@property (getter=isDraftModeEnabled,readwrite) BOOL draftModeEnabled;
@property (readwrite,retain) CIRAWDecoderVersion decoderVersion;
@property (readwrite) float scaleFactor;
@property (readwrite) float exposure;
@property (readwrite) float baselineExposure;
@property (readwrite) float shadowBias;
@property (readwrite) float boostAmount;
@property (readwrite) float boostShadowAmount;
@property (getter=isGamutMappingEnabled,readwrite) BOOL gamutMappingEnabled;
@property (getter=isLensCorrectionSupported,readonly) BOOL lensCorrectionSupported;
@property (getter=isLensCorrectionEnabled,readwrite) BOOL lensCorrectionEnabled;
@property (getter=isLuminanceNoiseReductionSupported,readonly) BOOL luminanceNoiseReductionSupported;
@property (readwrite) float luminanceNoiseReductionAmount;
@property (getter=isColorNoiseReductionSupported,readonly) BOOL colorNoiseReductionSupported;
@property (readwrite) float colorNoiseReductionAmount;
@property (getter=isSharpnessSupported,readonly) BOOL sharpnessSupported;
@property (readwrite) float sharpnessAmount;
@property (getter=isContrastSupported,readonly) BOOL contrastSupported;
@property (readwrite) float contrastAmount;
@property (getter=isDetailSupported,readonly) BOOL detailSupported;
@property (readwrite) float detailAmount;
@property (getter=isMoireReductionSupported,readonly) BOOL moireReductionSupported;
@property (readwrite) float moireReductionAmount;
@property (getter=isLocalToneMapSupported,readonly) BOOL localToneMapSupported;
@property (readwrite) float localToneMapAmount;
@property (readwrite) float extendedDynamicRangeAmount;
@property (readwrite) CGPoint neutralChromaticity;
@property (readwrite) CGPoint neutralLocation;
@property (readwrite) float neutralTemperature;
@property (readwrite) float neutralTint;
@property (readwrite,retain) CIFilter * linearSpaceFilter;
@property (readonly) CIImage * previewImage;
@property (readonly) CIImage * portraitEffectsMatte;
@property (readonly) CIImage * semanticSegmentationSkinMatte;
@property (readonly) CIImage * semanticSegmentationHairMatte;
@property (readonly) CIImage * semanticSegmentationGlassesMatte;
@property (readonly) CIImage * semanticSegmentationSkyMatte;
@property (readonly) CIImage * semanticSegmentationTeethMatte;
@end
@protocol CIRAWFilterClassExports<JSExport>
+(id) filterWithImageURL: (NSURL *) url ;
+(id) filterWithImageData: (NSData *) data identifierHint: (NSString *) identifierHint ;
+(id) filterWithCVPixelBuffer: (id) buffer properties: (NSDictionary *) properties ;
+(NSArray *) supportedCameraModels;
@end
@protocol CIFilterCIRAWFilterCategoryInstanceExports<JSExport>
@end
@protocol CIFilterCIRAWFilterCategoryClassExports<JSExport>
+(CIFilter *) filterWithImageURL: (NSURL *) url options: (NSDictionary *) options ;
+(CIFilter *) filterWithImageData: (NSData *) data options: (NSDictionary *) options ;
+(CIFilter *) filterWithCVPixelBuffer: (id) pixelBuffer properties: (NSDictionary *) properties options: (NSDictionary *) options ;
+(NSArray *) supportedRawCameraModels;
@end
#pragma clang diagnostic pop
#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIHIDRMSWrapperModules(JSContext* context);
JSValue* extractNFIHIDRMSWrapperStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIHIDRMSWrapperStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);

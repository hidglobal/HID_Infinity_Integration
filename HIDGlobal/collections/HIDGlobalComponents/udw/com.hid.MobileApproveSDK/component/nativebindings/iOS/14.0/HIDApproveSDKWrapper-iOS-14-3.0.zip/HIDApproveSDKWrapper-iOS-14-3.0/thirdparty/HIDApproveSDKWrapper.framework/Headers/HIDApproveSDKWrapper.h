//
//  ApproveSDKWrapper.h
//  ApproveSDKWrapper
//
//  Created by HID Bangalore on 19/04/21.
//

#import <Foundation/Foundation.h>
#import <JavaScriptCore/JavaScriptCore.h>
@interface HIDApproveSDKWrapper : NSObject
-(void)createContainer : (NSString *)activationCode withPushId :(NSString *)PushId withPwdCallBack:(JSValue *)pwdCallback withExCallback: (JSValue *) ExceptionCallback;
-(void)renewContainer : (NSString *)password withPwdCallBack:(JSValue *)promptCallback withExceptionCallBack: (JSValue *)ExceptionCallback;
-(void)setPasswordForUser : (NSString *)password;
-(NSString *)getLoginFlow : (NSString *)pushId callBack: (JSValue *) genericExecutionCallback;
-(void)generateOTP : (NSString *)password  isBioEnabled : (bool) bioEnabled withSuccessCB : (JSValue *)success_CB failureCB : (JSValue *)failure_CB;
-(void)enableBiometrics : (NSString *)password statusCB : (JSValue *)bioStatusCallback;
-(void)disableBiometrics;
-(bool)checkBioAvailability;
-(void) signTransaction : (NSString *)transactionDetails withPwdPromptCallback : (JSValue *) pwdPromptCallback withSuccessCB : (JSValue *) successCB withFailureCB : (JSValue *) failureCB;
-(NSString *) retreiveTransaction : (NSString *)txID;
-(void) setNotificationStatus : (NSString *) txID withStatus : (NSString *)status withJSCallback : (JSValue *) onCompleteCB withPwdPromptCB : (JSValue *)pwdPromptCB;
-(void) notifyPassword : (NSString *) password withMode : (NSString *)mode;
-(void) updatePassword : (NSString *) oldPassword newPassword : (NSString *)newPassword exceptionCallback : (JSValue *)ExceptionCallback isPasswordPolicy : (bool) isPasswordPolicy;
-(NSString *) getPasswordPolicy;
@end




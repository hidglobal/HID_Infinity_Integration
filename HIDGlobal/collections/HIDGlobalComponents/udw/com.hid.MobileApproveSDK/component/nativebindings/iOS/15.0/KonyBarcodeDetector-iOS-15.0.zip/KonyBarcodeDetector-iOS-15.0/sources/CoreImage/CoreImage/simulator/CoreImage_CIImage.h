#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreImage_CIImage_symbols(JSContext*);
@protocol CIImageInstanceExports<JSExport, NSSecureCodingInstanceExports_, NSCopyingInstanceExports_>
@property (readonly,nonatomic) CGRect extent;
@property (readonly,atomic) NSDictionary * properties;
@property (readonly,atomic) NSURL * url;
@property (readonly,atomic) id colorSpace;
@property (readonly,nonatomic) id pixelBuffer;
@property (readonly,nonatomic) id CGImage;
JSExportAs(initWithCGImage,
-(id) jsinitWithCGImage: (id) image );
JSExportAs(initWithCGImageOptions,
-(id) jsinitWithCGImage: (id) image options: (NSDictionary *) options );
JSExportAs(initWithCGImageSourceIndexOptions,
-(id) jsinitWithCGImageSource: (id) source index: (size_t) index options: (NSDictionary *) dict );
JSExportAs(initWithData,
-(id) jsinitWithData: (NSData *) data );
JSExportAs(initWithDataOptions,
-(id) jsinitWithData: (NSData *) data options: (NSDictionary *) options );
JSExportAs(initWithBitmapDataBytesPerRowSizeFormatColorSpace,
-(id) jsinitWithBitmapData: (NSData *) data bytesPerRow: (size_t) bytesPerRow size: (CGSize) size format: (CIFormat) format colorSpace: (id) colorSpace );
JSExportAs(initWithTextureSizeFlippedColorSpace,
-(id) jsinitWithTexture: (unsigned int) name size: (CGSize) size flipped: (BOOL) flipped colorSpace: (id) colorSpace );
JSExportAs(initWithMTLTextureOptions,
-(id) jsinitWithMTLTexture: (id) texture options: (NSDictionary *) options );
JSExportAs(initWithContentsOfURL,
-(id) jsinitWithContentsOfURL: (NSURL *) url );
JSExportAs(initWithContentsOfURLOptions,
-(id) jsinitWithContentsOfURL: (NSURL *) url options: (NSDictionary *) options );
JSExportAs(initWithIOSurface,
-(id) jsinitWithIOSurface: (id) surface );
JSExportAs(initWithIOSurfaceOptions,
-(id) jsinitWithIOSurface: (id) surface options: (NSDictionary *) options );
JSExportAs(initWithCVImageBuffer,
-(id) jsinitWithCVImageBuffer: (id) imageBuffer );
JSExportAs(initWithCVImageBufferOptions,
-(id) jsinitWithCVImageBuffer: (id) imageBuffer options: (NSDictionary *) options );
JSExportAs(initWithCVPixelBuffer,
-(id) jsinitWithCVPixelBuffer: (id) pixelBuffer );
JSExportAs(initWithCVPixelBufferOptions,
-(id) jsinitWithCVPixelBuffer: (id) pixelBuffer options: (NSDictionary *) options );
JSExportAs(initWithColor,
-(id) jsinitWithColor: (CIColor *) color );
-(CIImage *) imageByApplyingTransform: (CGAffineTransform) matrix ;
-(CIImage *) imageByApplyingTransform: (CGAffineTransform) matrix highQualityDownsample: (BOOL) highQualityDownsample ;
-(CIImage *) imageByApplyingOrientation: (int) orientation ;
-(CGAffineTransform) imageTransformForOrientation: (int) orientation ;
-(CIImage *) imageByApplyingCGOrientation: (CGImagePropertyOrientation) orientation ;
-(CGAffineTransform) imageTransformForCGOrientation: (CGImagePropertyOrientation) orientation ;
-(CIImage *) imageByCompositingOverImage: (CIImage *) dest ;
-(CIImage *) imageByCroppingToRect: (CGRect) rect ;
-(CIImage *) imageByClampingToExtent;
-(CIImage *) imageByClampingToRect: (CGRect) rect ;
-(CIImage *) imageByApplyingFilter: (NSString *) filterName withInputParameters: (NSDictionary *) params ;
-(CIImage *) imageByApplyingFilter: (NSString *) filterName ;
-(CIImage *) imageByColorMatchingColorSpaceToWorkingSpace: (id) colorSpace ;
-(CIImage *) imageByColorMatchingWorkingSpaceToColorSpace: (id) colorSpace ;
-(CIImage *) imageByPremultiplyingAlpha;
-(CIImage *) imageByUnpremultiplyingAlpha;
-(CIImage *) imageBySettingAlphaOneInExtent: (CGRect) extent ;
-(CIImage *) imageByApplyingGaussianBlurWithSigma: (double) sigma ;
-(CIImage *) imageBySettingProperties: (NSDictionary *) properties ;
-(CIImage *) imageBySamplingLinear;
-(CIImage *) imageBySamplingNearest;
-(CIImage *) imageByInsertingIntermediate;
-(CIImage *) imageByInsertingIntermediate: (BOOL) cache ;
-(CGRect) regionOfInterestForImage: (CIImage *) image inRect: (CGRect) rect ;
@end
@protocol CIImageClassExports<JSExport, NSSecureCodingClassExports_, NSCopyingClassExports_>
+(CIImage *) imageWithCGImage: (id) image ;
+(CIImage *) imageWithCGImage: (id) image options: (NSDictionary *) options ;
+(CIImage *) imageWithCGImageSource: (id) source index: (size_t) index options: (NSDictionary *) dict ;
+(CIImage *) imageWithBitmapData: (NSData *) data bytesPerRow: (size_t) bytesPerRow size: (CGSize) size format: (CIFormat) format colorSpace: (id) colorSpace ;
+(CIImage *) imageWithTexture: (unsigned int) name size: (CGSize) size flipped: (BOOL) flipped colorSpace: (id) colorSpace ;
+(CIImage *) imageWithMTLTexture: (id) texture options: (NSDictionary *) options ;
+(CIImage *) imageWithContentsOfURL: (NSURL *) url ;
+(CIImage *) imageWithContentsOfURL: (NSURL *) url options: (NSDictionary *) options ;
+(CIImage *) imageWithData: (NSData *) data ;
+(CIImage *) imageWithData: (NSData *) data options: (NSDictionary *) options ;
+(CIImage *) imageWithCVImageBuffer: (id) imageBuffer ;
+(CIImage *) imageWithCVImageBuffer: (id) imageBuffer options: (NSDictionary *) options ;
+(CIImage *) imageWithCVPixelBuffer: (id) pixelBuffer ;
+(CIImage *) imageWithCVPixelBuffer: (id) pixelBuffer options: (NSDictionary *) options ;
+(CIImage *) imageWithIOSurface: (id) surface ;
+(CIImage *) imageWithIOSurface: (id) surface options: (NSDictionary *) options ;
+(CIImage *) imageWithColor: (CIColor *) color ;
+(CIImage *) emptyImage;
+(CIImage *) blackImage;
+(CIImage *) whiteImage;
+(CIImage *) grayImage;
+(CIImage *) redImage;
+(CIImage *) greenImage;
+(CIImage *) blueImage;
+(CIImage *) cyanImage;
+(CIImage *) magentaImage;
+(CIImage *) yellowImage;
+(CIImage *) clearImage;
@end
@protocol CIImageAutoAdjustmentCategoryInstanceExports<JSExport>
-(NSArray *) autoAdjustmentFilters;
-(NSArray *) autoAdjustmentFiltersWithOptions: (NSDictionary *) options ;
@end
@protocol CIImageAutoAdjustmentCategoryClassExports<JSExport>
@end
@protocol CIImageAVDepthDataCategoryInstanceExports<JSExport>
@property (readonly,nonatomic) AVDepthData * depthData;
JSExportAs(initWithDepthDataOptions,
-(id) jsinitWithDepthData: (AVDepthData *) data options: (NSDictionary *) options );
JSExportAs(initWithDepthData,
-(id) jsinitWithDepthData: (AVDepthData *) data );
@end
@protocol CIImageAVDepthDataCategoryClassExports<JSExport>
+(id) imageWithDepthData: (AVDepthData *) data options: (NSDictionary *) options ;
+(id) imageWithDepthData: (AVDepthData *) data ;
@end
@protocol CIImageAVPortraitEffectsMatteCategoryInstanceExports<JSExport>
@property (readonly,nonatomic) AVPortraitEffectsMatte * portraitEffectsMatte;
JSExportAs(initWithPortaitEffectsMatteOptions,
-(id) jsinitWithPortaitEffectsMatte: (AVPortraitEffectsMatte *) matte options: (NSDictionary *) options );
JSExportAs(initWithPortaitEffectsMatte,
-(id) jsinitWithPortaitEffectsMatte: (AVPortraitEffectsMatte *) matte );
@end
@protocol CIImageAVPortraitEffectsMatteCategoryClassExports<JSExport>
+(id) imageWithPortaitEffectsMatte: (AVPortraitEffectsMatte *) matte options: (NSDictionary *) options ;
+(id) imageWithPortaitEffectsMatte: (AVPortraitEffectsMatte *) matte ;
@end
@protocol CIImageAVSemanticSegmentationMatteCategoryInstanceExports<JSExport>
@property (readonly,nonatomic) AVSemanticSegmentationMatte * semanticSegmentationMatte;
JSExportAs(initWithSemanticSegmentationMatteOptions,
-(id) jsinitWithSemanticSegmentationMatte: (AVSemanticSegmentationMatte *) matte options: (NSDictionary *) options );
JSExportAs(initWithSemanticSegmentationMatte,
-(id) jsinitWithSemanticSegmentationMatte: (AVSemanticSegmentationMatte *) matte );
@end
@protocol CIImageAVSemanticSegmentationMatteCategoryClassExports<JSExport>
+(id) imageWithSemanticSegmentationMatte: (AVSemanticSegmentationMatte *) matte options: (NSDictionary *) options ;
+(id) imageWithSemanticSegmentationMatte: (AVSemanticSegmentationMatte *) matte ;
@end
#pragma clang diagnostic pop
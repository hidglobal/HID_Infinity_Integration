#import "allincludes.h"
#import <JavaScriptCore/JavaScriptCore.h>
void loadNFIHID_Approve_SDKModules(JSContext* context)
{
	load_HID_Approve_SDK_HIDOTPGenerator_symbols(context);
	load_HID_Approve_SDK_HIDConstants_symbols(context);
	load_HID_Approve_SDK_HIDKey_symbols(context);
	load_HID_Approve_SDK_HIDOCRAGenerator_symbols(context);
	load_HID_Approve_SDK_HIDServerAction_symbols(context);
	load_HID_Approve_SDK_HIDTOTPGenerator_symbols(context);
	load_HID_Approve_SDK_HIDDevice_symbols(context);
	load_HID_Approve_SDK_HIDConnectionConfiguration_symbols(context);
	load_HID_Approve_SDK_HIDKeySpec_symbols(context);
	load_HID_Approve_SDK_HIDSyncOTPGenerator_symbols(context);
	load_HID_Approve_SDK_HIDHOTPGenerator_symbols(context);
	load_HID_Approve_SDK_HIDContainerInitialization_symbols(context);
	load_HID_Approve_SDK_HIDErrors_symbols(context);
	load_HID_Approve_SDK_HIDContainer_symbols(context);
	load_HID_Approve_SDK_HIDServerActionInfo_symbols(context);
	load_HID_Approve_SDK_HIDProtectionPolicy_symbols(context);
	load_HID_Approve_SDK_HIDTransaction_symbols(context);
	load_HID_Approve_SDK_HIDIdentifier_symbols(context);
	load_HID_Approve_SDK_HIDProgressListener_symbols(context);
	load_HID_Approve_SDK_HIDParameter_symbols(context);
	load_HID_Approve_SDK_HIDAsyncOTPGenerator_symbols(context);
}

JSValue* extractNFIHID_Approve_SDKStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context)
{
    
    return nil;
}

BOOL setNFIHID_Approve_SDKStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation)
{
    
    return NO;
}


#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
	context[@"SSL_NULL_WITH_NULL_NULL"] = @0U;
	context[@"SSL_RSA_WITH_NULL_MD5"] = @1U;
	context[@"SSL_RSA_WITH_NULL_SHA"] = @2U;
	context[@"SSL_RSA_EXPORT_WITH_RC4_40_MD5"] = @3U;
	context[@"SSL_RSA_WITH_RC4_128_MD5"] = @4U;
	context[@"SSL_RSA_WITH_RC4_128_SHA"] = @5U;
	context[@"SSL_RSA_EXPORT_WITH_RC2_CBC_40_MD5"] = @6U;
	context[@"SSL_RSA_WITH_IDEA_CBC_SHA"] = @7U;
	context[@"SSL_RSA_EXPORT_WITH_DES40_CBC_SHA"] = @8U;
	context[@"SSL_RSA_WITH_DES_CBC_SHA"] = @9U;
	context[@"SSL_RSA_WITH_3DES_EDE_CBC_SHA"] = @10U;
	context[@"SSL_DH_DSS_EXPORT_WITH_DES40_CBC_SHA"] = @11U;
	context[@"SSL_DH_DSS_WITH_DES_CBC_SHA"] = @12U;
	context[@"SSL_DH_DSS_WITH_3DES_EDE_CBC_SHA"] = @13U;
	context[@"SSL_DH_RSA_EXPORT_WITH_DES40_CBC_SHA"] = @14U;
	context[@"SSL_DH_RSA_WITH_DES_CBC_SHA"] = @15U;
	context[@"SSL_DH_RSA_WITH_3DES_EDE_CBC_SHA"] = @16U;
	context[@"SSL_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA"] = @17U;
	context[@"SSL_DHE_DSS_WITH_DES_CBC_SHA"] = @18U;
	context[@"SSL_DHE_DSS_WITH_3DES_EDE_CBC_SHA"] = @19U;
	context[@"SSL_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA"] = @20U;
	context[@"SSL_DHE_RSA_WITH_DES_CBC_SHA"] = @21U;
	context[@"SSL_DHE_RSA_WITH_3DES_EDE_CBC_SHA"] = @22U;
	context[@"SSL_DH_anon_EXPORT_WITH_RC4_40_MD5"] = @23U;
	context[@"SSL_DH_anon_WITH_RC4_128_MD5"] = @24U;
	context[@"SSL_DH_anon_EXPORT_WITH_DES40_CBC_SHA"] = @25U;
	context[@"SSL_DH_anon_WITH_DES_CBC_SHA"] = @26U;
	context[@"SSL_DH_anon_WITH_3DES_EDE_CBC_SHA"] = @27U;
	context[@"SSL_FORTEZZA_DMS_WITH_NULL_SHA"] = @28U;
	context[@"SSL_FORTEZZA_DMS_WITH_FORTEZZA_CBC_SHA"] = @29U;
	context[@"TLS_RSA_WITH_AES_128_CBC_SHA"] = @47U;
	context[@"TLS_DH_DSS_WITH_AES_128_CBC_SHA"] = @48U;
	context[@"TLS_DH_RSA_WITH_AES_128_CBC_SHA"] = @49U;
	context[@"TLS_DHE_DSS_WITH_AES_128_CBC_SHA"] = @50U;
	context[@"TLS_DHE_RSA_WITH_AES_128_CBC_SHA"] = @51U;
	context[@"TLS_DH_anon_WITH_AES_128_CBC_SHA"] = @52U;
	context[@"TLS_RSA_WITH_AES_256_CBC_SHA"] = @53U;
	context[@"TLS_DH_DSS_WITH_AES_256_CBC_SHA"] = @54U;
	context[@"TLS_DH_RSA_WITH_AES_256_CBC_SHA"] = @55U;
	context[@"TLS_DHE_DSS_WITH_AES_256_CBC_SHA"] = @56U;
	context[@"TLS_DHE_RSA_WITH_AES_256_CBC_SHA"] = @57U;
	context[@"TLS_DH_anon_WITH_AES_256_CBC_SHA"] = @58U;
	context[@"TLS_ECDH_ECDSA_WITH_NULL_SHA"] = @49153U;
	context[@"TLS_ECDH_ECDSA_WITH_RC4_128_SHA"] = @49154U;
	context[@"TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA"] = @49155U;
	context[@"TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA"] = @49156U;
	context[@"TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA"] = @49157U;
	context[@"TLS_ECDHE_ECDSA_WITH_NULL_SHA"] = @49158U;
	context[@"TLS_ECDHE_ECDSA_WITH_RC4_128_SHA"] = @49159U;
	context[@"TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA"] = @49160U;
	context[@"TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA"] = @49161U;
	context[@"TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA"] = @49162U;
	context[@"TLS_ECDH_RSA_WITH_NULL_SHA"] = @49163U;
	context[@"TLS_ECDH_RSA_WITH_RC4_128_SHA"] = @49164U;
	context[@"TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA"] = @49165U;
	context[@"TLS_ECDH_RSA_WITH_AES_128_CBC_SHA"] = @49166U;
	context[@"TLS_ECDH_RSA_WITH_AES_256_CBC_SHA"] = @49167U;
	context[@"TLS_ECDHE_RSA_WITH_NULL_SHA"] = @49168U;
	context[@"TLS_ECDHE_RSA_WITH_RC4_128_SHA"] = @49169U;
	context[@"TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA"] = @49170U;
	context[@"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA"] = @49171U;
	context[@"TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA"] = @49172U;
	context[@"TLS_ECDH_anon_WITH_NULL_SHA"] = @49173U;
	context[@"TLS_ECDH_anon_WITH_RC4_128_SHA"] = @49174U;
	context[@"TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA"] = @49175U;
	context[@"TLS_ECDH_anon_WITH_AES_128_CBC_SHA"] = @49176U;
	context[@"TLS_ECDH_anon_WITH_AES_256_CBC_SHA"] = @49177U;
	context[@"TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA"] = @49205U;
	context[@"TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA"] = @49206U;
	context[@"TLS_PSK_WITH_CHACHA20_POLY1305_SHA256"] = @52395U;
	context[@"TLS_NULL_WITH_NULL_NULL"] = @0U;
	context[@"TLS_RSA_WITH_NULL_MD5"] = @1U;
	context[@"TLS_RSA_WITH_NULL_SHA"] = @2U;
	context[@"TLS_RSA_WITH_RC4_128_MD5"] = @4U;
	context[@"TLS_RSA_WITH_RC4_128_SHA"] = @5U;
	context[@"TLS_RSA_WITH_3DES_EDE_CBC_SHA"] = @10U;
	context[@"TLS_RSA_WITH_NULL_SHA256"] = @59U;
	context[@"TLS_RSA_WITH_AES_128_CBC_SHA256"] = @60U;
	context[@"TLS_RSA_WITH_AES_256_CBC_SHA256"] = @61U;
	context[@"TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA"] = @13U;
	context[@"TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA"] = @16U;
	context[@"TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA"] = @19U;
	context[@"TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA"] = @22U;
	context[@"TLS_DH_DSS_WITH_AES_128_CBC_SHA256"] = @62U;
	context[@"TLS_DH_RSA_WITH_AES_128_CBC_SHA256"] = @63U;
	context[@"TLS_DHE_DSS_WITH_AES_128_CBC_SHA256"] = @64U;
	context[@"TLS_DHE_RSA_WITH_AES_128_CBC_SHA256"] = @103U;
	context[@"TLS_DH_DSS_WITH_AES_256_CBC_SHA256"] = @104U;
	context[@"TLS_DH_RSA_WITH_AES_256_CBC_SHA256"] = @105U;
	context[@"TLS_DHE_DSS_WITH_AES_256_CBC_SHA256"] = @106U;
	context[@"TLS_DHE_RSA_WITH_AES_256_CBC_SHA256"] = @107U;
	context[@"TLS_DH_anon_WITH_RC4_128_MD5"] = @24U;
	context[@"TLS_DH_anon_WITH_3DES_EDE_CBC_SHA"] = @27U;
	context[@"TLS_DH_anon_WITH_AES_128_CBC_SHA256"] = @108U;
	context[@"TLS_DH_anon_WITH_AES_256_CBC_SHA256"] = @109U;
	context[@"TLS_PSK_WITH_RC4_128_SHA"] = @138U;
	context[@"TLS_PSK_WITH_3DES_EDE_CBC_SHA"] = @139U;
	context[@"TLS_PSK_WITH_AES_128_CBC_SHA"] = @140U;
	context[@"TLS_PSK_WITH_AES_256_CBC_SHA"] = @141U;
	context[@"TLS_DHE_PSK_WITH_RC4_128_SHA"] = @142U;
	context[@"TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA"] = @143U;
	context[@"TLS_DHE_PSK_WITH_AES_128_CBC_SHA"] = @144U;
	context[@"TLS_DHE_PSK_WITH_AES_256_CBC_SHA"] = @145U;
	context[@"TLS_RSA_PSK_WITH_RC4_128_SHA"] = @146U;
	context[@"TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA"] = @147U;
	context[@"TLS_RSA_PSK_WITH_AES_128_CBC_SHA"] = @148U;
	context[@"TLS_RSA_PSK_WITH_AES_256_CBC_SHA"] = @149U;
	context[@"TLS_PSK_WITH_NULL_SHA"] = @44U;
	context[@"TLS_DHE_PSK_WITH_NULL_SHA"] = @45U;
	context[@"TLS_RSA_PSK_WITH_NULL_SHA"] = @46U;
	context[@"TLS_RSA_WITH_AES_128_GCM_SHA256"] = @156U;
	context[@"TLS_RSA_WITH_AES_256_GCM_SHA384"] = @157U;
	context[@"TLS_DHE_RSA_WITH_AES_128_GCM_SHA256"] = @158U;
	context[@"TLS_DHE_RSA_WITH_AES_256_GCM_SHA384"] = @159U;
	context[@"TLS_DH_RSA_WITH_AES_128_GCM_SHA256"] = @160U;
	context[@"TLS_DH_RSA_WITH_AES_256_GCM_SHA384"] = @161U;
	context[@"TLS_DHE_DSS_WITH_AES_128_GCM_SHA256"] = @162U;
	context[@"TLS_DHE_DSS_WITH_AES_256_GCM_SHA384"] = @163U;
	context[@"TLS_DH_DSS_WITH_AES_128_GCM_SHA256"] = @164U;
	context[@"TLS_DH_DSS_WITH_AES_256_GCM_SHA384"] = @165U;
	context[@"TLS_DH_anon_WITH_AES_128_GCM_SHA256"] = @166U;
	context[@"TLS_DH_anon_WITH_AES_256_GCM_SHA384"] = @167U;
	context[@"TLS_PSK_WITH_AES_128_GCM_SHA256"] = @168U;
	context[@"TLS_PSK_WITH_AES_256_GCM_SHA384"] = @169U;
	context[@"TLS_DHE_PSK_WITH_AES_128_GCM_SHA256"] = @170U;
	context[@"TLS_DHE_PSK_WITH_AES_256_GCM_SHA384"] = @171U;
	context[@"TLS_RSA_PSK_WITH_AES_128_GCM_SHA256"] = @172U;
	context[@"TLS_RSA_PSK_WITH_AES_256_GCM_SHA384"] = @173U;
	context[@"TLS_PSK_WITH_AES_128_CBC_SHA256"] = @174U;
	context[@"TLS_PSK_WITH_AES_256_CBC_SHA384"] = @175U;
	context[@"TLS_PSK_WITH_NULL_SHA256"] = @176U;
	context[@"TLS_PSK_WITH_NULL_SHA384"] = @177U;
	context[@"TLS_DHE_PSK_WITH_AES_128_CBC_SHA256"] = @178U;
	context[@"TLS_DHE_PSK_WITH_AES_256_CBC_SHA384"] = @179U;
	context[@"TLS_DHE_PSK_WITH_NULL_SHA256"] = @180U;
	context[@"TLS_DHE_PSK_WITH_NULL_SHA384"] = @181U;
	context[@"TLS_RSA_PSK_WITH_AES_128_CBC_SHA256"] = @182U;
	context[@"TLS_RSA_PSK_WITH_AES_256_CBC_SHA384"] = @183U;
	context[@"TLS_RSA_PSK_WITH_NULL_SHA256"] = @184U;
	context[@"TLS_RSA_PSK_WITH_NULL_SHA384"] = @185U;
	context[@"TLS_AES_128_GCM_SHA256"] = @4865U;
	context[@"TLS_AES_256_GCM_SHA384"] = @4866U;
	context[@"TLS_CHACHA20_POLY1305_SHA256"] = @4867U;
	context[@"TLS_AES_128_CCM_SHA256"] = @4868U;
	context[@"TLS_AES_128_CCM_8_SHA256"] = @4869U;
	context[@"TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256"] = @49187U;
	context[@"TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384"] = @49188U;
	context[@"TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256"] = @49189U;
	context[@"TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384"] = @49190U;
	context[@"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256"] = @49191U;
	context[@"TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384"] = @49192U;
	context[@"TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256"] = @49193U;
	context[@"TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384"] = @49194U;
	context[@"TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256"] = @49195U;
	context[@"TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384"] = @49196U;
	context[@"TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256"] = @49197U;
	context[@"TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384"] = @49198U;
	context[@"TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256"] = @49199U;
	context[@"TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384"] = @49200U;
	context[@"TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256"] = @49201U;
	context[@"TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384"] = @49202U;
	context[@"TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256"] = @52392U;
	context[@"TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256"] = @52393U;
	context[@"TLS_EMPTY_RENEGOTIATION_INFO_SCSV"] = @255U;
	context[@"SSL_RSA_WITH_RC2_CBC_MD5"] = @65408U;
	context[@"SSL_RSA_WITH_IDEA_CBC_MD5"] = @65409U;
	context[@"SSL_RSA_WITH_DES_CBC_MD5"] = @65410U;
	context[@"SSL_RSA_WITH_3DES_EDE_CBC_MD5"] = @65411U;
	context[@"SSL_NO_SUCH_CIPHERSUITE"] = @65535U;


	context[@"kSSLCiphersuiteGroupDefault"] = @0;
	context[@"kSSLCiphersuiteGroupCompatibility"] = @1;
	context[@"kSSLCiphersuiteGroupLegacy"] = @2;
	context[@"kSSLCiphersuiteGroupATS"] = @3;
	context[@"kSSLCiphersuiteGroupATSCompatibility"] = @4;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void load_Security_CipherSuite_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop

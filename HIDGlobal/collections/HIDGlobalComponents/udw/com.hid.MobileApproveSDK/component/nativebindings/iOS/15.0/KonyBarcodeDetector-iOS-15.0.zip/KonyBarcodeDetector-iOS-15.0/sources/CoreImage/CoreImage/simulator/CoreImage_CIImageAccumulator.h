#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreImage_CIImageAccumulator_symbols(JSContext*);
@protocol CIImageAccumulatorInstanceExports<JSExport>
@property (readonly) CGRect extent;
@property (readonly) CIFormat format;
JSExportAs(initWithExtentFormat,
-(id) jsinitWithExtent: (CGRect) extent format: (CIFormat) format );
JSExportAs(initWithExtentFormatColorSpace,
-(id) jsinitWithExtent: (CGRect) extent format: (CIFormat) format colorSpace: (id) colorSpace );
-(CIImage *) image;
-(void) setImage: (CIImage *) image ;
-(void) setImage: (CIImage *) image dirtyRect: (CGRect) dirtyRect ;
-(void) clear;
@end
@protocol CIImageAccumulatorClassExports<JSExport>
+(id) imageAccumulatorWithExtent: (CGRect) extent format: (CIFormat) format ;
+(id) imageAccumulatorWithExtent: (CGRect) extent format: (CIFormat) format colorSpace: (id) colorSpace ;
@end
#pragma clang diagnostic pop
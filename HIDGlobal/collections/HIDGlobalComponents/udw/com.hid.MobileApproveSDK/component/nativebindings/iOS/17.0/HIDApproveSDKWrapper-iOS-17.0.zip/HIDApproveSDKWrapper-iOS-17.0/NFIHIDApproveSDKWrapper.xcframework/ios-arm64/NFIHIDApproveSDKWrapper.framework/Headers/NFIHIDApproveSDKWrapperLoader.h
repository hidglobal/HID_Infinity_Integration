#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIHIDApproveSDKWrapperModules(JSContext* context);
JSValue* extractNFIHIDApproveSDKWrapperStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIHIDApproveSDKWrapperStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);

#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_HID_Approve_SDK_HIDParameter_symbols(JSContext*);
@protocol HIDParameterInstanceExports<JSExport>
@property (assign,nonatomic) HIDParameterType type;
@property (retain,nonatomic) NSString * value;
@property (retain,nonatomic) NSString * key;
@property (assign,nonatomic) HIDParameterEncoding encoding;
JSExportAs(initWithStringForKey,
-(id) jsinitWithString: (NSString *) value forKey: (NSString *) key );
@end
@protocol HIDParameterClassExports<JSExport>
+(id) parameterWithString: (NSString *) value forKey: (NSString *) key ;
@end
#pragma clang diagnostic pop
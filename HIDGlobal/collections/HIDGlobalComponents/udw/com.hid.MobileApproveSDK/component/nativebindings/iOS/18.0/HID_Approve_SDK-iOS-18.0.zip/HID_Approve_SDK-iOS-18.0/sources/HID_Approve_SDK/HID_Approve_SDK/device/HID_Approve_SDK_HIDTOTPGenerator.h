#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_HID_Approve_SDK_HIDTOTPGenerator_symbols(JSContext*);
@protocol HIDTOTPAlgorithmParametersInstanceExports_<JSExport, HIDHOTPAlgorithmParametersInstanceExports_>
-(uint64_t) getTimeStep;
-(uint64_t) getClock;
-(uint64_t) getStartTime;
@end
@protocol HIDTOTPAlgorithmParametersClassExports_<JSExport, HIDHOTPAlgorithmParametersClassExports_>
@end
#pragma clang diagnostic pop